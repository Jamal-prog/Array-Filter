#include <stdio.h>
#define SIZE 20

int even(int a) {
	return a % 2 == 0;
}
int odd(int a) {
	return a % 2 == 1;
}
int lessThanOrEqualTo5(int a) {
	return a <= 5;
}
int greaterThan5(int a) {
	return a > 5;
}

void filter(const int* data, int size, int* filterResult, int (*filterFunc)(int)) {
	for (int i = 0; i < size; i++) {
		filterResult[i] = filterFunc(data[i]);
	}
}
void DisplayArray(const int* arr1, int size) {
	for (int i = 0; i < size; i++)
	{
		printf("%d\t", arr1[i]);
	}
}
int main(void) {
	int selection;
	int data[SIZE] = { 3,6,4,5,1,4,5,3,9,9,2,2,2,4,7,5,7,2,4,5 };
	int filterResult[SIZE] = { 0 };

	printf("Data: ");
	DisplayArray(data, SIZE);

	while (1) {
		printf("Choose the filtering type: \n");
		printf("1 - Odd\n");
		printf("2 - Even\n");
		printf("3 - Less Than 5\n");
		printf("4 - Greater or Equal to 5\n");
		printf(">> ");
		scanf("%d", &selection);
		switch (selection)
		{
		case 1:	//Even
			printf("Data: ");
			DisplayArray(data, SIZE);
			filter(data, SIZE, filterResult, even);
			printf("Filter: ");
			DisplayArray(filterResult, SIZE);
			break;
		case 2: //Odd
			printf("Data: ");
			DisplayArray(data, SIZE);
			filter(data, SIZE, filterResult, odd);
			printf("Filter: ");
			DisplayArray(filterResult, SIZE);
			break;
		case 3:	//Less Than or Equal to 5
			printf("Data: ");
			DisplayArray(data, SIZE);
			filter(data, SIZE, filterResult, lessThanOrEqualTo5);
			printf("Filter: ");
			DisplayArray(filterResult, SIZE);
			break;
		case 4: //Greater than 5
			printf("Data: ");
			DisplayArray(data, SIZE);
			filter(data, SIZE, filterResult, greaterThan5);
			printf("Filter: ");
			DisplayArray(filterResult, SIZE);
			break;
		default:
			break;
		}

	}

	//filter(data, SIZE, filterResult, odd);
	//printf("Filter: ");
	//DisplayArray(filterResult, SIZE);
	return 0;
}